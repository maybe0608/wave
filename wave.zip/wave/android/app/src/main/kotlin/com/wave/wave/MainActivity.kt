package com.wave.wave

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
