import 'package:flutter/material.dart';

class PubSection extends StatelessWidget {
  const PubSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color.fromARGB(255, 241, 241, 241),
      height: 10,
    );
  }
}
